Some very simple code to play with the Kinova Gen3 arm in python and ROS2.
