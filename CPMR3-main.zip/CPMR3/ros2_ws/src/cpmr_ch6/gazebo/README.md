Copy these directories to ~/.gazebo/models
