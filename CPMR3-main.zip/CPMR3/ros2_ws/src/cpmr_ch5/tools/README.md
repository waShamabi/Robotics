Some (possibly) useful tools

- calibrate.py takes a collection of jpg's of a known calibration target and computes the calibration matrix
- mktarget.py creates an image of an ARUCO target
