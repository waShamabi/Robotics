# CPMR3

This repository provides the code base for CPMR 3rd Edition.

Note that only limited support is available for ROS 1 (noetic)
More complete support is available for ROS 2 (humble)

The pdf document at the root of this repository provides a very (very) brief introduciton to ROS and a description of some of the sample code that is available in this repository.


