gazebo-camera.launch - launch the robot with a camera
aruco.py - run the aruco target system
canny_edges.py - find Canny edges
good_features.py - find good features to track
harris_corner.py - show Harris corners
view_camera.py - display what the camera is capturing
square_node.py - move the robot in a square

The directory gazebo_models should go into ~/.gazebo/models
