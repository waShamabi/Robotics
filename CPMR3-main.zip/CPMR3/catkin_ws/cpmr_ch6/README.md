Material associated with Chapter 6.

