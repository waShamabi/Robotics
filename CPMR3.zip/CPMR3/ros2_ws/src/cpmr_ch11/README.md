Chapter 11 provides the following launch files

* chairs.launch.py - launch a collection of wheelchairs

Examining the transformation graph shows how multiple robots can be deployed in a common space with different name spaces for each robot.


