This package provides the definition of a block robot
(a stand in for a point robot) in ROS.

Full documentation on this package can be found in Computational Principles of Mobile Robotics 3rd Edition.



